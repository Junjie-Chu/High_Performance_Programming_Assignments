#include <stdio.h>
#include <stdlib.h>
//Forward declaration of functions pascal and print_pascal
int pascal(int row, int col);
void print_pascal(int n);

int main(int argc, char** argv){
	int n = atoi(argv[1]); //convert argv[1] to integer
	print_pascal(n); //call to function print_pascal
	return 0; //safe exit
}
//Function to calculate the binomial coefficient
int pascal(int row, int col){
//Initialize product to 1 since it's multiplication
	int product =1;
//k represents i in the binomial coefficient formula product form
	int k = 1;
//Apply product formula given the current col and row
	for (int i = 0; i < col; ++i) {
		//caclulate product value at every iteration and add it to the current value 
		product *= row + 1 - k; // calculate the numerator 
		product /= k; // denominator starts from 1 and goes up at every loop iteration 
		k++; //increment denominator
	}
//Return the resulting product
	return product;
}
//Function to print the elements in lower triangle fashion
void print_pascal(int n){
	for (int i=0; i < n; ++i){ //iterate the rows corresponding to arginput n
		for (int j=0; j <= i; ++j){ //iterate the cols while #col <= #row in order to print lower triangle
				printf("%i ", pascal(i,j)); //print the product
			}
			putchar('\n'); //new line every row
		}
}
