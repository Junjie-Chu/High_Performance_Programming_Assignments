#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node {
	int id;
	double min, max;
	struct node *next;
}node_t;
//Forward declaration
void insert(node_t **head, int id, double min, double max);
void print_list(node_t * head);
void deleteNode(node_t **head, int key); 
void freememory(node_t **head);

int main(){
	char command[100], *arguments[4];
	node_t* head=NULL;
	do{
	printf("Enter command:");
	scanf(" %[^\n]", command);
	int i = 0;
//Use strtok, iterate through the command array split at " ". strtok returns NULL when everything is parsed  
	for (char *c = strtok(command," "); c != NULL; c = strtok(NULL, " ")){ arguments[i] = c; i++;}
	switch ( command[0] ){
		case 'A':
		insert(&head, atoi(arguments[1]), atof(arguments[2]), atof(arguments[3])); 
		break;
		case 'D':
		deleteNode(&head, atoi(arguments[1]));
		break;
		case 'P':
		print_list(head);
		break;
		case 'Q':
		freememory(&head);
		return 0;
		default:
		printf("%s is not a valid command. Valid Commands are, A index min max, D index, P - print, Q - exit", command);
		putchar('\n'); 
	}
	}while (command[0] != 'Q');
	return 0;
}

//Function that prints the linked list in the specified format
void print_list(node_t * head){
    node_t * current = head;
		printf("day\tmin\t\tmax\n");
    while (current != NULL) {
        printf("%i\t%lf\t%lf\n", current->id, current->min, current->max);
        current = current->next;
    }
}

//Function to insert nodes in the linked list
void insert(node_t **head, int id, double min, double max){
		node_t *current = *head;
		node_t *new_node = NULL;
		node_t *temp; 
		//Create the new node
		new_node=(node_t *)malloc(sizeof(node_t));
		if (new_node == NULL ){
			printf("Failed to insert elements. Out of memory");
			return;
		}
		
		new_node->id = id; new_node->min = min; new_node->max = max, new_node->next = NULL;
		
		if( *head == NULL){ 
		*head = new_node; 
		}else{
			//If the id is matching the id of head the update the temperatures and return
			if (current->id == id){ current->min = min; current->max = max; return; }
			//Find node with id value just before the id, determines position of curr based on argument id 
			while(current->next != NULL && current->next->id < id ){ current = current->next; }
		
		//Check if the entry is unique to the current->next->id if it is then add a new node in between and
		//link it with current->next, in other words if you have entries with ID[1,3] and you want to add entry
		//with id = 2 the following if statement gets activated
		if ( current->next != NULL && new_node->id != current->next->id ){
			temp = current->next; //make a copy of the node to be "nudged"
			current->next = new_node; //link the new node with previous node
			new_node->next = temp; // link new node with next node
			
		//If the entry is not unique , id exists but not on the edges
		}else if ( current->next != NULL && new_node->id == current->next->id ){
			current->next->min = min; current->next->max = max; free(new_node);
		//else add it at the end of the list
		}else if(current->next == NULL){
			temp = current->next; current->next = new_node; new_node->next = temp;
		}
	}
}

void deleteNode(node_t **head, int id){ 
    // Store head node 
    node_t* temp = *head, *prev; 
  
    // If head node itself holds the id to be deleted 
    if (temp != NULL && temp->id == id) 
    { 
        *head = temp->next;   // Changed head 
        free(temp);          // free old head 
        return; 
    } 
  	// Search for the id to be deleted, keep track of the 
    // previous node as we need to change 'prev->next' 
    while (temp != NULL && temp->id != id) 
    { 
        prev = temp; 
        temp = temp->next; 
    } 
  	//If id was not present in linked list 
    if (temp == NULL) return; 
  	//Unlink the node from linked list 
    prev->next = temp->next; 
  	free(temp);  // Free memory 
} 

//Function to delete the linked list by deallocating the memory upon exit
void freememory(node_t **head){
 	node_t* current = *head;
 	node_t* next;
 	while( current != NULL){
 		next = current->next;
 		free(current);
 		current = next;
 	}
 	*head = NULL;
 	printf("Exit..");
}
