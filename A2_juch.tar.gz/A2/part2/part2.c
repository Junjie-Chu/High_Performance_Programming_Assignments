#include<stdio.h>

int main()
{
	int a = 2;
	int i;
	double d;
	char c;
	float f;
	FILE *fp;
	//Open the file in "rb" mode, read binary
	fp=fopen("little_bin_file","rb");
	
	//Read the first 4 bytes into i
	fread(&i,sizeof(i),1,fp);
	//read the next 8 bytes so it reads bytes [5 to 12] into d
	fread(&d, sizeof(d), 1, fp);
	//read the next 1 byte , byte 13 into c
	fread(&c, sizeof(c), 1, fp);
	//read the next 4 bytes [14 to 17] into f
	fread(&f, sizeof(f), 1, fp);
	//Print the values in speciied format
	printf("%i\n %f\n %c\n %.1f\n", i, d, c, f);
	//Close the file
	fclose(fp);
	return 0;
}

