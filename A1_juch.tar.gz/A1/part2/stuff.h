#define G 77

void print_pyramid(int pyramidSize);
