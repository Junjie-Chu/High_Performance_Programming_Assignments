#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>
// The struct to store input data and output data
typedef struct body
{
	double m;
	double b;
	double px;
	double py;
	double vx;
	double vy;
	double fx;
	double fy;
} Body;
// the node struct of quadtree
typedef struct treenode
{
	double m;
	double px;
	double py;
	// the type of the node:root0,intermediate1,body2,unknown3
	int type;
	// four subtrees
	struct treenode *quadrant1;
	struct treenode *quadrant2;
	struct treenode *quadrant3;
	struct treenode *quadrant4;
} treeNode;

Body *array;
int num;
int old = 0; //old == 0 means a new node added
int checkt = 4;
int checkq = 0;

// the function to measure time
static double get_wall_seconds()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
	return seconds;
}

//read data
void readdata(char *filename, int num)
{
	FILE *fp;
	int i;

	fp = fopen(filename, "rb+");
	if (fp == NULL)
	{
		printf("==================================\n");
		printf("Error! No such file!\n");
		printf("==================================\n");
		exit(1);
	}

	printf("==================================\n");
	printf("read data... \n");
	printf("array num:%d \n", num);

	array = (Body *)malloc(num * sizeof(Body));
	rewind(fp);
	for (i = 0; i < num; i++)
	{
		fread(&array[i].px, sizeof(double), 1, fp);
		fread(&array[i].py, sizeof(double), 1, fp);

		fread(&array[i].m, sizeof(double), 1, fp);
		fread(&array[i].vx, sizeof(double), 1, fp);
		fread(&array[i].vy, sizeof(double), 1, fp);

		fread(&array[i].b, sizeof(double), 1, fp);
		array[i].fx = 0;
		array[i].fy = 0;
	}
	printf("==================================\n");
	fclose(fp);
}

//write data
void writedata(Body *array, int num)
{
	FILE *fout;
	int i;
	remove("result.gal");
	fout = fopen("result.gal", "wb+");
	if (fout == NULL)
	{
		printf("==================================\n");
		printf("Error! No such output file!\n");
		printf("==================================\n");
		exit(1);
	}

	printf("==================================\n");
	printf("write data... \n");
	printf("array num:%d \n", num);
	rewind(fout);
	for (i = 0; i < num; i++)
	{
		fwrite(&array[i].px, sizeof(double), 1, fout);
		fwrite(&array[i].py, sizeof(double), 1, fout);
		fwrite(&array[i].m, sizeof(double), 1, fout);
		fwrite(&array[i].vx, sizeof(double), 1, fout);
		fwrite(&array[i].vy, sizeof(double), 1, fout);
		fwrite(&array[i].b, sizeof(double), 1, fout);
	}
	printf("==================================\n");
	fclose(fout);
}

//create node
treeNode *createNode()
{	
	treeNode *node = (treeNode *)malloc(sizeof(treeNode));
	if (node)
	{
		node->quadrant1 = node->quadrant2 = NULL;
		node->quadrant3 = node->quadrant4 = NULL;
		node->m = node->px = node->py = 0.0;
		node->type = 3;
	}

	return node;
}

//fill node
treeNode *fillNode(treeNode *node, int type, double m, double px, double py)
{
	
	if (node)
	{
			node->m = m;
			node->px = px;
			node->py = py;
			node->type = type;
	}else
	{
		printf("Null node!");
		exit(1);
	}

	return node;
}

//expand tree
treeNode *expand(treeNode *node, int type, double m, double px, double py, int N, double x1, double x2, double y1, double y2)
{
	//according to midx and midy, the domain could be splitted into 4 parts
	double midx, midy, newm;
	midx = (x1 + x2) / 2;
	midy = (y1 + y2) / 2;
	//change center of the object when a new node is being added
	if (old == 0)
	{
		newm = m + node->m;
		node->px = ((node->m * node->px) + (m * px)) / newm;
		node->py = ((node->m * node->py) + (m * py)) / newm;
		node->m = newm;
	}
	if (px >= midx && py >= midy)
	{
		checkq = 1;
	}
	else if (px < midx && py >= midy)
	{
		checkq = 2;
	}
	else if (px < midx && py < midy)
	{
		checkq = 3;
	}
	else
	{
		checkq = 4;
	}
	switch (checkq)
	{
	//quadrant1
	case 1:
	{
		//if quadrant1-childnode is null, add the new node
		if (!(node->quadrant1))
		{
			checkt = -1;
		}
		else
		{
			checkt = node->quadrant1->type;
		}

		switch (checkt)
		{
		case -1:
		{
			node->quadrant1 = createNode();
			node->quadrant1 = fillNode(node->quadrant1,type,m,px,py);
			break;
		}
		case 0:
			break;
		//if quadrant1-childnode's type is 1, represents that this node is not a body node containing data, we can add the new node directly
		case 1:
			node->quadrant1 = expand(node->quadrant1, type, m, px, py, N, midx, x2, midy, y2);
			break;

		//else, the quadrant1-childnode is a body node containing data, we need to insert branch
		case 2:
		{
			int tmpt;
			double tmpm, tmppx, tmppy;
			old = old + 1;
			tmpt = node->quadrant1->type;
			tmpm = node->quadrant1->m;
			tmppx = node->quadrant1->px;
			tmppy = node->quadrant1->py;
			//copy the old node
			node->quadrant1 = expand(node->quadrant1, tmpt, tmpm, tmppx, tmppy, N, midx, x2, midy, y2);
			//add the new node
			old = old - 1;
			node->quadrant1 = expand(node->quadrant1, type, m, px, py, N, midx, x2, midy, y2);
			//Now node->quadrant1 is an intermediate node
			if (node->quadrant1->type != 1){node->quadrant1->type = 1;}
			break;
		}
		case 3:
			break;
		default:
			break;
		}
		break;
	}
	//quadrant2
	case 2:
	{
		if (!(node->quadrant2))
		{
			checkt = -1;
		}
		else
		{
			checkt = node->quadrant2->type;
		}
		switch (checkt)
		{
		case -1:
		{
			node->quadrant2 = createNode();
			node->quadrant2 = fillNode(node->quadrant2,type,m,px,py);
			break;
		}
		case 0:
			break;
		case 1:
			node->quadrant2 = expand(node->quadrant2, type, m, px, py, N, x1, midx, midy, y2);
			break;
		case 2:
		{
			int tmpt;
			double tmpm, tmppx, tmppy;
			old = old + 1;
			tmpt = node->quadrant2->type;
			tmpm = node->quadrant2->m;
			tmppx = node->quadrant2->px;
			tmppy = node->quadrant2->py;
			node->quadrant2 = expand(node->quadrant2, tmpt, tmpm, tmppx, tmppy, N, x1, midx, midy, y2);
			old = old - 1;
			node->quadrant2 = expand(node->quadrant2, type, m, px, py, N, x1, midx, midy, y2);
			if (node->quadrant2->type != 1){node->quadrant2->type = 1;}
			break;
		}
		case 3:
			break;
		default:
			break;
		}
		break;
	}
	//quadrant3
	case 3:
	{
		if (!(node->quadrant3))
		{
			checkt = -1;
		}
		else
		{
			checkt = node->quadrant3->type;
		}
		switch (checkt)
		{
		case -1:
		{
			node->quadrant3 = createNode();
			node->quadrant3 = fillNode(node->quadrant3,type,m,px,py);
			break;
		}
		case 0:
			break;
		case 1:
			node->quadrant3 = expand(node->quadrant3, type, m, px, py, N, x1, midx, y1, midy);
			break;
		case 2:
		{
			int tmpt;
			double tmpm, tmppx, tmppy;
			old = old + 1;
			tmpt = node->quadrant3->type;
			tmpm = node->quadrant3->m;
			tmppx = node->quadrant3->px;
			tmppy = node->quadrant3->py;
			node->quadrant3 = expand(node->quadrant3, tmpt, tmpm, tmppx, tmppy, N, x1, midx, y1, midy);
			old = old - 1;
			node->quadrant3 = expand(node->quadrant3, type, m, px, py, N, x1, midx, y1, midy);
			if (node->quadrant3->type != 1){node->quadrant3->type = 1;}
			break;
		}
		case 3:
			break;
		default:
			break;
		}
		break;
	}
	//quadrant4
	case 4:
	{
		if (!(node->quadrant4))
		{
			checkt = -1;
		}
		else
		{
			checkt = node->quadrant4->type;
		}
		switch (checkt)
		{
		case -1:
		{
			node->quadrant4 = createNode();
			node->quadrant4 = fillNode(node->quadrant4,type,m,px,py);
			break;
		}
		case 0:
			break;
		case 1:
			node->quadrant4 = expand(node->quadrant4, type, m, px, py, N, midx, x2, y1, midy);
			break;
		case 2:
		{
			int tmpt;
			double tmpm, tmppx, tmppy;
			old = old + 1;
			tmpt = node->quadrant4->type;
			tmpm = node->quadrant4->m;
			tmppx = node->quadrant4->px;
			tmppy = node->quadrant4->py;
			node->quadrant4 = expand(node->quadrant4, tmpt, tmpm, tmppx, tmppy, N, midx, x2, y1, midy);
			old = old - 1;
			node->quadrant4 = expand(node->quadrant4, type, m, px, py, N, midx, x2, y1, midy);
			if (node->quadrant4->type != 1){node->quadrant4->type = 1;}
			break;
		}
		case 3:
			break;
		default:
			break;
		}
		break;
	}
	default:
		break;
	}
	return node;
}

//delete Tree
void deleteTree(treeNode *node)
{
	if (node)
	{
		deleteTree(node->quadrant1);
		deleteTree(node->quadrant2);
		deleteTree(node->quadrant3);
		deleteTree(node->quadrant4);
		free(node);
	}
}

//calculate the force
void calculateF(treeNode *node, Body *array, double Qmax, double width, int N)
{
	//xi is x2-x1, yi is y2-y1, use x*x instead of pow to improve the performance
	double G, e, xi, yi, r, Q;
	G = (double)100 / N;
	e = 1e-3;
	xi = array->px - node->px;
	yi = array->py - node->py;
	r = xi * xi + yi * yi;
	r = sqrt(r);
	if (r != 0)
	{
		Q = width / r + e;
	} //else{printf("error!");exit(1);}
	// Root node or intermediate node, no data
	if (node->type < 2 && Q > Qmax)
	{
		if (node->quadrant1)
		{
			calculateF(node->quadrant1, array, Qmax, width / 2.0, N);
		}
		if (node->quadrant2)
		{
			calculateF(node->quadrant2, array, Qmax, width / 2.0, N);
		}
		if (node->quadrant3)
		{
			calculateF(node->quadrant3, array, Qmax, width / 2.0, N);
		}
		if (node->quadrant4)
		{
			calculateF(node->quadrant4, array, Qmax, width / 2.0, N);
		}
	}
	else
	{
		r = (r + e) * (r + e) * (r + e);
		array->fx = -G * (node->m * xi / r) + array->fx;
		array->fy = -G * (node->m * yi / r) + array->fy;
	}
}

void updateVP(Body *array, int num, double deltat)

{

	int i = 0;
	while (i < num)
	{
		//update velocity of each array 1 step
		array[i].vx += deltat * array[i].fx;
		array[i].vy += deltat * array[i].fy;
		//update position of each array 1 step
		array[i].px += deltat * array[i].vx;
		array[i].py += deltat * array[i].vy;
		i++;
	}
}
//************************************main********************************************
int main(int argc, char *argv[])
{
	if (argc == 7)
	{
		//printf("Running.......\n\n");
	}
	else
	{
		printf("Wrong number of arguments!\n\n");
		exit(1);
	}

	int N = atoi(argv[1]);
	num = N;
	readdata(argv[2], num);
	int nsteps = atoi(argv[3]);
	double deltat = atof(argv[4]);
	double Qmax = atof(argv[5]);

	// measure time1
	double time1 = get_wall_seconds();

	//main part
	for (int j = 0; j < nsteps; j++)
	{

		treeNode *root = createNode();
		root->type = 0;
		// put the bodies into the tree to get some equivalent particle
		for (int i = 0; i < N; i++)
		{

			double x1, y1, x2, y2;
			int type;
			x1 = x2 = 0.0;
			y1 = y2 = 1.0;
			type = 2;
			root = expand(root, type, array[i].m, array[i].px, array[i].py, N, x1, y1, x2, y2);
		}

		for (int i = 0; i < num; i++)
		{
			array[i].fx = 0;
			array[i].fy = 0;
			//calculate the force each array gets
			calculateF(root, &array[i], Qmax, 1.0, N);
		}

		updateVP(array, num, deltat);

		deleteTree(root);
	}

	// measure time2
	double time2 = get_wall_seconds();
	printf("Time spent:%f\n\n", time2 - time1);

	// show the result
	printf("the fisrt 10 final results:\n");
	int k;
	for (k = 0; k < 10; k++)
	{
		printf("arraye[%d]:p(%lf,%lf),v(%lf,%lf)\n", k, array[k].px, array[k].py, array[k].vx, array[k].vy);
	}

	writedata(array, num);
	printf("==================================\n");
	//system("pause");
	free(array);
	return 0;
}
