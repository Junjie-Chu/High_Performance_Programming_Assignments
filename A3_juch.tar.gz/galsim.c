#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include <sys/time.h>

typedef struct {
	double m;
	double b;
	double px;
	double py;
	double vx;
	double vy;
	
}Body;

Body* array;
int num;

static double get_wall_seconds() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
  return seconds;
}

// read data
void readdata(char* filename ,int num)
{
	FILE* fp;
	int i;

	fp = fopen(filename, "rb+");
	if (fp == NULL) {
		printf("==================================\n");
		printf("Error! No such file!\n");
		printf("==================================\n");
		exit(1);
	}

	printf("==================================\n");
	printf("read data... \n");
	printf("array num:%d \n", num);

	array = (Body*)malloc(num * sizeof(Body));
	rewind(fp);
	for (i = 0;i < num;i++)
	{
		fread(&array[i].px, sizeof(double), 1, fp);
		fread(&array[i].py, sizeof(double), 1, fp);
		
		fread(&array[i].m, sizeof(double), 1, fp);
		fread(&array[i].vx, sizeof(double), 1, fp);
		fread(&array[i].vy, sizeof(double), 1, fp);
		
		fread(&array[i].b, sizeof(double), 1, fp);
	}
	printf("==================================\n");
	fclose(fp);
	/*
	int j;
	for (j = 0;j < num;j++)
	{
		printf("array[%d]:p(%lf,%lf,%lf),v(%lf,%lf,%lf)\n", j, array[j].px, array[j].py, array[j].vx, array[j].vy);
	}*/
}

//write data
void writedata(Body* array, int num)
{
	FILE* fout;
	int i;
	remove("result.gal");
	fout = fopen("result.gal", "wb+");
	if (fout == NULL) {
		printf("==================================\n");
		printf("Error! No such output file!\n");
		printf("==================================\n");
		exit(1);
	}

	printf("==================================\n");
	printf("write data... \n");
	printf("array num:%d \n", num);
	rewind(fout);
	for (i = 0;i < num;i++)
	{
		fwrite(&array[i].px, sizeof(double), 1, fout);
		fwrite(&array[i].py, sizeof(double), 1, fout);
		fwrite(&array[i].m, sizeof(double), 1, fout);
		fwrite(&array[i].vx, sizeof(double), 1, fout);
		fwrite(&array[i].vy, sizeof(double), 1, fout);
		fwrite(&array[i].b, sizeof(double), 1, fout);
		//printf("array[%d]:p(%lf,%lf,%lf),v(%lf,%lf,%lf)\n", i, array[i].px, array[i].py, array[i].vx, array[i].vy);
	}
	printf("==================================\n");
	fclose(fout);

}

//calculate the position of 1 timestep version1
void calculateP(Body* array, int num, double deltat)  
{
	int i, j;
	double T;
	double fx;
	double fy;
	double vx;
	double vy;
	double px;
	double py;
	double e = 1e-3;
	double G;

	T = deltat;
	G = 100 / num;

	for (i = 0;i < num;i++)
	{
		vx = 0;
		vy = 0;
		px = 0;
		py = 0;
		fx = 0;
		fy = 0;
		for (j = 0;j < num;j++)
		{
			double xi = array[j].px - array[i].px;
			double yi = array[j].py - array[i].py;
		
			double r = 0;
			if (i == j) continue;
			/*calculate the distance*/
			r = xi * xi + yi * yi ;
			r = pow((sqrt(r)+e),3);
			if (r == 0.0) continue; /*igonre the particles having the same position*/
			/*calculate the gravity(no mass i)*/
			fx += G * array[j].m * xi / r;
			fy += G * array[j].m * yi / r;
		}
		vx = fx * T;//a*t,delta v
		vy = fy * T;

		//printf("\nAccX:%lf,AccY:%lf\n", vx, vy);
		/*
		px = (array[i].vx + vx / 2) * T;//v*t+0.5*a*t^2
		py = (array[i].vy + vy / 2) * T;

		px = T * (array[i].vx + vx);
		py = T * (array[i].vy + vy);*/
		/*update the v and p*/
		array[i].vx += vx;
		array[i].vy += vy;


	}		
	for (i = 0;i < num;i++){
		array[i].px = array[i].px + T*array[i].vx;
		array[i].py = array[i].py + T * array[i].vy;
	}
	/*
	printf("the result in the timestep:\n");
	int k;
	for (k = 0;k < num;k++)
	{
		printf("p:array[%d]:(%f,%f,%f)\n", k, array[k].px, array[k].py);
		printf("v:array[%d]:(%f,%f,%f)\n", k, array[k].vx, array[k].vy);
	}*/
}
//calculate the position of 1 timestep version2
void calculateP2(Body* array, int num, double deltat)
{
	int i, j;
	double T;
	double fx;
	double fy;

	double vx;
	double vy;

	double px;
	double py;

	double e = 1e-3;
	double G;

	T = deltat;
	G = 100 / num;

	for (i = 0;i < num;i++)
	{
		vx = 0;
		vy = 0;

		px = 0;
		py = 0;

		fx = 0;
		fy = 0;

		for (j = 0;j < i;j++)
		{
			double xi = array[j].px - array[i].px;
			double yi = array[j].py - array[i].py;

			double r = 0;
			if (i == j) continue;
			/*calculate the distance*/
			r = xi * xi + yi * yi ;
			r = pow((sqrt(r) + e), 3);
			if (r == 0.0) continue; /*igonre the particles having the same position*/
			/*calculate the gravity(no mass i)*/
			fx += G * array[j].m * xi / r;
			fy += G * array[j].m * yi / r;
			
			//printf("j:%d,fx:%lf,fy:%lf\n", j, fx, fy);
		}

		for (j = i+1;j < num;j++)
		{
			double xi = array[j].px - array[i].px;
			double yi = array[j].py - array[i].py;
			
			double r = 0;
			if (i == j) continue;
			/*calculate the distance*/
			r = xi * xi + yi * yi ;
			r = pow((sqrt(r) + e), 3);
			if (r == 0.0) continue; /*igonre the particles having the same position*/
			/*calculate the gravity(no mass i)*/
			fx += G * array[j].m * xi / r;
			fy += G * array[j].m * yi / r;
			
			//printf("j:%d,fx:%lf,fy:%lf\n", j, fx, fy);
		}

		//printf("fx:%lf,fy:%lf\n", fx, fy);


		vx = fx * T;//a*t,delta v
		vy = fy * T;
		

		array[i].vx += vx;
		array[i].vy += vy;
		

	}

	for (i = 0;i < num;i++) {
		array[i].px = array[i].px + T * array[i].vx;
		array[i].py = array[i].py + T * array[i].vy;
		
	}

}

//calculate the position of 1 timestep version3
void calculateP3(Body* array, int num, double deltat)
{
	int i, j;
	double T;
	double fx;
	double fy;

	double vx;
	double vy;

	double px;
	double py;

	double xi1, yi1, r1;
	double xi2, yi2, r2;
	double e = 1e-3;
	double G;

	T = deltat;
	G = 100 / num;

	for (i = 0;i < num;i++)
	{
		vx = 0;
		vy = 0;

		px = 0;
		py = 0;
		
		fx = 0;
		fy = 0;
	
		if (i % 2 == 0) {
			//printf("case1,i:%d\n", i);
			for (j = 0;j < i;j=j+2) {
				
				xi1 = array[j].px - array[i].px;
				yi1 = array[j].py - array[i].py;
				
				r1 = 0;
				xi2 = array[j+1].px - array[i].px;
				yi2 = array[j+1].py - array[i].py;
				
				r2 = 0;

				r1 = xi1 * xi1 + yi1 * yi1 ;
				r1 = pow((sqrt(r1) + e), 3);
				if (r1 == 0.0) continue;

				r2 = xi2 * xi2 + yi2 * yi2 ;
				r2 = pow((sqrt(r2) + e), 3);
				if (r2 == 0.0) continue;

				fx = fx + G * array[j].m * xi1 / r1 + G * array[j+1].m * xi2 / r2;
				fy = fy + G * array[j].m * yi1 / r1 + G * array[j+1].m * yi2 / r2;
				
				//printf("j:%d,fx:%lf,fy:%lf\n", j, fx, fy);
			}
		}
		else  {//if (i % 2 == 1)
			//printf("case2,i:%d\n", i);
			for (j = 0;j < i-1;j = j + 2) {
				
				xi1 = array[j].px - array[i].px;
				yi1 = array[j].py - array[i].py;
				
				r1 = 0;
				xi2 = array[j + 1].px - array[i].px;
				yi2 = array[j + 1].py - array[i].py;
				
				r2 = 0;

				r1 = xi1 * xi1 + yi1 * yi1 ;
				r1 = pow((sqrt(r1) + e), 3);
				if (r1 == 0.0) continue;

				r2 = xi2 * xi2 + yi2 * yi2 ;
				r2 = pow((sqrt(r2) + e), 3);
				if (r2 == 0.0) continue;

				fx = fx + G * array[j].m * xi1 / r1 + G * array[j + 1].m * xi2 / r2;
				fy = fy + G * array[j].m * yi1 / r1 + G * array[j + 1].m * yi2 / r2;
				
				//printf("j:%d,fx:%lf,fy:%lf\n", j, fx, fy);
			}
			xi2 = array[i - 1].px - array[i].px;
			yi2 = array[i - 1].py - array[i].py;
			
			r2 = xi2 * xi2 + yi2 * yi2 ;
			r2 = pow((sqrt(r2) + e), 3);
			if (r2 == 0.0) continue;
			fx = fx + G * array[i - 1].m * xi2 / r2;
			fy = fy + G * array[i - 1].m * yi2 / r2;
			
		}
		if ((num - i) % 2 == 1) { //i=7,num=10,8/9
			//printf("case3,i:%d\n", i);
			for (j = i+1;j < num;j = j + 2) {
				xi1 = array[j].px - array[i].px;
				yi1 = array[j].py - array[i].py;
				
				r1 = 0;
				xi2 = array[j + 1].px - array[i].px;
				yi2 = array[j + 1].py - array[i].py;
				
				r2 = 0;

				r1 = xi1 * xi1 + yi1 * yi1 ;
				r1 = pow((sqrt(r1) + e), 3);
				if (r1 == 0.0) continue;

				r2 = xi2 * xi2 + yi2 * yi2 ;
				r2 = pow((sqrt(r2) + e), 3);
				if (r2 == 0.0) continue;

				fx = fx + G * array[j].m * xi1 / r1 + G * array[j + 1].m * xi2 / r2;
				fy = fy + G * array[j].m * yi1 / r1 + G * array[j + 1].m * yi2 / r2;
				
				//printf("j:%d,fx:%lf,fy:%lf\n", j, fx, fy);
			}
			//printf("fx:%lf,fy:%lf\n", fx, fy);
		}
		else  {//if ((num - i) % 2 == 0)//i=6,num=10,7/8/9
			//printf("case4,i:%d\n", i);
			for (j = i+1;j < num - 1;j = j + 2) {
				xi1 = array[j].px - array[i].px;
				yi1 = array[j].py - array[i].py;
				
				r1 = 0;
				xi2 = array[j + 1].px - array[i].px;
				yi2 = array[j + 1].py - array[i].py;
				
				r2 = 0;

				r1 = xi1 * xi1 + yi1 * yi1 ;
				r1 = pow((sqrt(r1) + e), 3);
				if (r1 == 0.0) continue;

				r2 = xi2 * xi2 + yi2 * yi2 ;
				r2 = pow((sqrt(r2) + e), 3);
				if (r2 == 0.0) continue;

				fx = fx + G * array[j].m * xi1 / r1 + G * array[j + 1].m * xi2 / r2;
				fy = fy + G * array[j].m * yi1 / r1 + G * array[j + 1].m * yi2 / r2;
				
				//printf("j:%d,fx:%lf,fy:%lf\n",j, fx, fy);
			}
			xi2 = array[num - 1].px - array[i].px;
			yi2 = array[num - 1].py - array[i].py;
			
			r2 = xi2 * xi2 + yi2 * yi2 ;
			r2 = pow((sqrt(r2) + e), 3);
			if (r2 == 0.0) continue;
			fx = fx + G * array[num - 1].m * xi2 / r2;
			fy = fy + G * array[num - 1].m * yi2 / r2;
			
			//printf("GFno:%d,GFx:%lf,GFy:%lf\n", num-1, G* array[num - 1].m* xi2 / r2, fy + G * array[num - 1].m * yi2 / r2);
			//printf("fx:%lf,fy:%lf\n", fx, fy);
		}

		vx = fx * T;//a*t,delta v
		vy = fy * T;
		



		array[i].vx += vx;
		array[i].vy += vy;
		

	}

	for (i = 0;i < num;i++) {
		array[i].px = array[i].px + T * array[i].vx;
		array[i].py = array[i].py + T * array[i].vy;
		
	}

}

int main(int argc, char* argv[])
{	
	if (argc != 6) {
		printf("Wrong number of arguments!\n\n");
		return 1;
	}
	int N = 0;//N and num are the number of stars
	int nsteps;//number of timesteps
	double deltat;//delta t
	int t = 0;
	clock_t t1;
	clock_t t2;
	//clock_t t3;
	//clock_t t4;
	//clock_t t5;
	//clock_t t6;

	N = atoi(argv[1]);
	num = N;
	
	nsteps = atoi(argv[3]);
	deltat = atof(argv[4]);
	// version 1
	readdata(argv[2],num);
	t1 = clock();
	double time1 = get_wall_seconds();
	for (t = 0;t < nsteps;t++)
	{
		calculateP2(array, num, deltat);
	}
	double time2 = get_wall_seconds();
	t2 = clock();
	printf("get_wall_seconds required for the calculations:%f\n\n",time2-time1);
	printf("Running time of the version is : %ld clicks (%f seconds)\n",t2-t1,((float)t2-(float)t1)/ CLOCKS_PER_SEC);
	printf("==================================\n");


	/*
	//version 3
	readdata(argv[2], num);
	t5 = clock();
	for (t = 0;t < nsteps;t=t+5)
	{
		calculateP3(array, num, deltat);
		calculateP3(array, num, deltat);
		calculateP3(array, num, deltat);
		calculateP3(array, num, deltat);
		calculateP3(array, num, deltat);

	}
	t6 = clock();
	printf("Running time of version 3 is : %ld clicks (%f seconds)\n", t6 - t5, ((float)t6 - (float)t5) / CLOCKS_PER_SEC);
	printf("==================================\n");

	//version 2
	readdata(argv[2], num);
	t3 = clock();
	for (t = 0;t < nsteps;t++)
	{
		calculateP2(array, num, deltat);
	}
	t4 = clock();
	printf("Running time of version 2 is : %ld clicks (%f seconds)\n", t4 - t3, ((float)t4 - (float)t3) / CLOCKS_PER_SEC);
	printf("==================================\n");*/
	

	printf("the fisrt 10 final results:\n");
	int k;
	for (k = 0;k < 10;k++)
	{
		printf("array[%d]:p(%lf,%lf),v(%lf,%lf)\n", k, array[k].px, array[k].py,array[k].vx, array[k].vy);
	}

	writedata(array,num);
	printf("==================================\n");
	//system("pause");
	free(array);
	return 0;
}
