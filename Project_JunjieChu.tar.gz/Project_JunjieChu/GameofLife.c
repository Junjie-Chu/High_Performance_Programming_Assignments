#define _CRT_SECURE_NO_WARNINGS
#define _CRT_NONSTDC_NO_DEPRECATE
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <math.h>
#include <pmmintrin.h>     /* SSE3 */
#include <assert.h>
#include <sys/time.h>
#define ROW 2000
#define COL 2000
#define NUM_THREADS     4
/*This is the final version. author Junjie Chu. date 2021 March*/
typedef struct {
	int G;
	int start;
	int end;
} thread_argument;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t signal = PTHREAD_COND_INITIALIZER;

pthread_barrier_t b;
const int DEAD=0;
const int ALIVE=1;
const int MAXROW=ROW+2;
const int MAXCOL=COL+2;
static const int Table[9] = {0, 0, 0, 1, 0, 0, 0, 0, 0};
int *map = NULL;
int *newmap = NULL;
int ready = 0;
int step = 0;
int input = 0;

void init();
int neighbors(int, int, int*);
void outputMap(int *);
//void compare(int* , int* )
// the function to measure time
static double get_wall_seconds()
{
	struct timeval tv;
	gettimeofday(&tv, NULL);
	double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
	return seconds;
}

void thread_barrier_start(int* plocstep)
{
	pthread_mutex_lock(&lock); 
	ready++;
	int* ptr = plocstep; 
	(*ptr)++; 
	if (ready==NUM_THREADS)
	{ ready=0; step++; pthread_cond_broadcast(&signal);} 
	//printf("\nthread id=%lu,ready:%d ,locstep:%d ,step:%d \n",pthread_self(),ready,*plocstep,step);
	pthread_mutex_unlock(&lock);
}

void thread_barrier_end(int locstep)
{
	pthread_mutex_lock(&lock); 
	//printf("\nthread id=%lu,locstep:%d ,step:%d \n",pthread_self(),locstep,step);
	while (locstep>step) {pthread_cond_wait(&signal,&lock);} 
	pthread_mutex_unlock(&lock);
}

void* threadfunc(void* argument)
{
  thread_argument *thread_arg = (thread_argument *) argument;
  int G = thread_arg->G;
  int start = thread_arg->start;
  int end = thread_arg->end;
  int locstep = 0;
  int* locmap = NULL;
  int* locnewmap = NULL;
  int* p;
  p = &locstep;
  locmap = map;
  locnewmap = newmap;
  //printf("\ncheck how many times\n");
  //outputMap(locnewmap);
  for(int g=0; g < G; g++)
  { 
    
    //pthread_barrier_wait(&b);
    thread_barrier_start(p);
    //printf("\nlocstep:%d\n",locstep);
    int *temp = NULL;
    temp = locmap;
    locmap = locnewmap;
    locnewmap = temp;
    
    //update inner points
    for (int row = start+1; row <= end-1; row++)
    { 
      for (int col = 1; col < COL+1; col++)
      { 
      	register int neighbor = 0;
      	neighbor = neighbors(row, col, locmap);
      	locnewmap[row*(MAXCOL)+col] = Table[neighbor];
        if (neighbor==2){locnewmap[row*(MAXCOL)+col] = locmap[row*(MAXCOL)+col];}

      }
    }

    
    thread_barrier_end(locstep);

    
    //update start and end row
    for (int col = 1; col < COL+1; col++)
      { 
      	register int neighbor = 0;
      	neighbor = neighbors(start, col, locmap);
      	locnewmap[start*(MAXCOL)+col] = Table[neighbor];
        if (neighbor==2){locnewmap[start*(MAXCOL)+col] = locmap[start*(MAXCOL)+col];}

      }
    for (int col = 1; col < COL+1; col++)
      { 
      	register int neighbor = 0;
      	neighbor = neighbors(end, col, locmap);
      	locnewmap[end*(MAXCOL)+col] = Table[neighbor];
        if (neighbor==2){locnewmap[end*(MAXCOL)+col] = locmap[end*(MAXCOL)+col];}

      }
    
    /*  
    printf("\ng=%d ----------------------------------------------------------\n",g);
    outputMap(locnewmap);
    outputMap(map);
    outputMap(newmap);
    printf("\n---------------------------------------------------------------\n");*/   
  }
  
  pthread_mutex_lock(&lock);
  map = locnewmap;
  newmap = locmap;
  pthread_mutex_unlock(&lock);
  locnewmap = NULL;
  locmap = NULL;
}


//void copyMap();
int main()
{
  int G;
  //time_t t;
  //srand((unsigned) time(&t));
  map = (int *)malloc((MAXROW)*(MAXCOL)*sizeof(int *)); 
  newmap = (int *)malloc((MAXROW)*(MAXCOL)*sizeof(int *));
  if(!map){printf("map malloc fails!");}; 
  if(!newmap){printf("newmap malloc fails!");};
  
  init();
  printf("Show the input status:");
  outputMap(newmap);
  
  
  
  int blockSz = ceil((double)ROW/NUM_THREADS); //When trying different number of threads
  printf("\nblockSz:%d\n",blockSz);
  int resto = ROW % NUM_THREADS; //When trying different number of threads
  printf("\nresto:%d\n",resto);
  //const int blockSz = ROW/NUM_THREADS;
  
  printf("\nHow Many Generations You Want? ");
  input = scanf("%d", &G);
  
  pthread_attr_t attr; 
  pthread_attr_init( &attr ); 
  pthread_attr_setdetachstate(&attr,1);
  
  pthread_t *threads = malloc(NUM_THREADS * sizeof(pthread_t));
  thread_argument *thread_args = malloc(NUM_THREADS * sizeof(thread_argument));
  pthread_barrier_init(&b,NULL,NUM_THREADS);
  int first = 1;
  for (int t = 0; t < NUM_THREADS; t++) {
	thread_args[t].G = G;
	thread_args[t].start = first;
	thread_args[t].end = first+blockSz-1;
	printf("\n the index is %d. start %d ,end %d\n",t,thread_args[t].start,thread_args[t].end);
	first = first + blockSz;
	if (t == resto - 1) blockSz--;//When trying different number of threads
	}
  
  // measure time1
  double time1 = get_wall_seconds();
  /*
  //Reduce thread swapping 
  for (int t = 0; t < NUM_THREADS-1; t++) {	
	pthread_create(&threads[t],NULL,threadfunc,(void *) &thread_args[t]);}
	
  threadfunc((void*)&thread_args[NUM_THREADS-1]);

  for (int t = 0; t < NUM_THREADS-1; t++) {
	pthread_join(threads[t], NULL);
	}
  */
  for (int t = 0; t < NUM_THREADS; t++) {	
	pthread_create(&threads[t],NULL,threadfunc,(void *) &thread_args[t]);}

  for (int t = 0; t < NUM_THREADS; t++) {
	pthread_join(threads[t], NULL);
	}
  
  // measure time2
  double time2 = get_wall_seconds();
  printf("\nTime spent:%f\n", time2 - time1);
  
  printf("\nShow the final status:\n");
  outputMap(map);
  //outputMap(newmap);
  printf("\n");
  pthread_barrier_destroy(&b);
  pthread_mutex_destroy(&lock);
  pthread_cond_destroy(&signal);
  free(threads);
  free(thread_args);
  free(map);
  free(newmap);
  map =NULL;
  newmap=NULL;
  return 0;
}
 
void init()
{ 
  int mode, row, col;
  memset(map,0,(MAXROW)*(MAXCOL)*sizeof(*map));
  memset(newmap,0,(MAXROW)*(MAXCOL)*sizeof(*newmap));           
  puts("Game of life Program");
  puts("Choose mode: 1 = random, else = manual");
  input = scanf("%d", &mode);
  if (mode == 1){
  	for (int row =1; row<ROW+1;row++)
    	{
    	   for (int col = 1; col<COL+1;col++)
    	   {
    	      newmap[row*MAXCOL+col]=(int)rand()%2;
    	      //printf("%d, %d\n",row,col);
    	   }
   	 }
  }
  else
  {
  	puts("Enter x, y where x, y is living cell");
  	printf("1 <= x <= %d, 1 <= y <= %d\n", ROW , COL );
  	puts("Terminate with x, y = -1, -1");
  	while (1)
  	{ 
    	input = scanf("%d %d", &row, &col);
    	if (0 < row && row < ROW+1 && 0 < col && col < COL+1)
      	{newmap[row*MAXCOL+col] = ALIVE;}
    	else if (row ==  - 1 || col ==  - 1)
      	{break;} 
    	else
      	{printf("(x, y) exceeds map ranage!\n");}
  	}
  }
}
 

inline int neighbors(int row, int col, int * maps)
{ 
  register int count;
  int a[8];
  a[0]=maps[(row-1)*(MAXCOL)+col-1];a[1]=maps[(row-1)*(MAXCOL)+col];
  a[2]=maps[(row-1)*(MAXCOL)+col+1];a[3]=maps[row*(MAXCOL)+col-1];
  a[4]=maps[row*(MAXCOL)+col+1];a[5]=maps[(row+1)*(MAXCOL)+col-1];
  a[6]=maps[(row+1)*(MAXCOL)+col];a[7]=maps[(row+1)*(MAXCOL)+col+1];
  for(int i=0;i<8;i++)
  	{count += a[i];}
  	
  return count;
}
 

void outputMap(int * maps)
{
  int row, col;
  printf("\nGame of life cell status(only 20*20 matrix)\n");
  for (row = 490; row < 510; row++)
  {
    printf("\n%20c", ' ');
    for (col = 490; col < 510; col++)
      if (maps[row*(MAXCOL)+col] == ALIVE)
       {putchar(' ');
        putchar('#');}
      else
       {putchar(' ');
        putchar('-');}
  }
}
/*
void compare(int* map1, int* map2)
{   
    int diff = 0;
    for (int row =1; row<MAXROW-1;row++)
       for (int col = 1; col<MAXCOL-1;col++)
       {
       if(map1[row*MAXCOL+col]!=map2[row*MAXCOL+col])
       {
       	diff++;
       }
       }
     printf("\nNumber of difference is %d\n",diff);
}*/

        
